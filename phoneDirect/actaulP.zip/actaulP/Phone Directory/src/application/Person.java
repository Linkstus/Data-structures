package application;

public class Person {
    String name;
    int age;
    long number;

    public Person(String name) {
        this.name = name;
    }
    
    public void setNumber(long number) {
    	this.number = number;
    }
    
    public void setAge(int age) {
    	this.age = age;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public long getNumber() {
        return number;
    }
    
    @Override
    public String toString() {
    	return name + " " + age;
    }
    
}